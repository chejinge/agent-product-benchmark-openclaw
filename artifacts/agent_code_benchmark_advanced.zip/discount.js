
// discount.js
function applyDiscount(basePrice, discountRate, isHoliday) {
    // BUG: 叠加顺序错误
    if (isHoliday) {
        basePrice *= 0.9; // 10% holiday discount
    }
    basePrice = basePrice * (1 - discountRate); // discountRate 叠加逻辑错误
    return basePrice;
}

module.exports = { applyDiscount };
