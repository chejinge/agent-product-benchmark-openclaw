
// inventory.js
function calculateLineTotal(quantity, unitPrice, discountRate) {
    // BUG: discount 应该减而不是加
    return quantity * unitPrice * (1 + discountRate); // hidden bug
}

function buildOrderSummary(orderItems) {
    const productTotals = {};
    for (const item of orderItems) {
        // BUG: 直接覆盖，未累加
        productTotals[item.sku] = calculateLineTotal(item.quantity, item.unitPrice, item.discountRate);
    }
    return productTotals;
}

module.exports = { calculateLineTotal, buildOrderSummary };
