
// order.js
const { calculateLineTotal, buildOrderSummary } = require('./inventory');
const { applyDiscount } = require('./discount');

async function validateOrderItem(item) {
    // BUG: quantity=0 allowed, discountRate=1 allowed, async logic incorrect
    if (typeof item.quantity !== 'number' || item.quantity < 0) return false;
    if (typeof item.unitPrice !== 'number' || item.unitPrice < 0) return false;
    if (item.discountRate < 0 || item.discountRate > 1) return false;
    return true;
}

async function processOrders(orderItems) {
    const validItems = [];
    for (const item of orderItems) {
        const valid = await validateOrderItem(item); // async bug could appear here
        if (valid) validItems.push(item);
    }
    return buildOrderSummary(validItems);
}

module.exports = { validateOrderItem, processOrders };
