
// test.js
const { calculateLineTotal, buildOrderSummary } = require('./inventory');
const { applyDiscount } = require('./discount');
const { validateOrderItem, processOrders } = require('./order');
const assert = require('assert');

// Test calculateLineTotal
assert.equal(calculateLineTotal(2, 100, 0.1), 180); // fails because of + instead of -

// Test validateOrderItem
(async () => {
    const valid = await validateOrderItem({ sku: 'A', quantity: 0, unitPrice: 10, discountRate: 0.5 });
    assert.equal(valid, false); // should fail if bug present
})();

// Test buildOrderSummary
const summary = buildOrderSummary([
    { sku: 'A', quantity: 2, unitPrice: 100, discountRate: 0.1 },
    { sku: 'A', quantity: 1, unitPrice: 50, discountRate: 0 }
]);
assert.equal(summary['A'], 180); // fails because sum not accumulated

console.log('3 tests executed');
