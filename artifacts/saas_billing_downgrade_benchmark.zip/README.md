# SaaS Billing Downgrade Benchmark

This project tests coding agents on a realistic SaaS billing workflow.

The agent must implement:
- subscription downgrade
- unpaid invoice guard
- prorated refund calculation
- mock billing API
- subscription API with 409 retry handling
- rollback when downgrade fails after refund success
- credit note generation
- customer and finance emails
- audit logs
- idempotency

Do not modify files under `tests/`.
