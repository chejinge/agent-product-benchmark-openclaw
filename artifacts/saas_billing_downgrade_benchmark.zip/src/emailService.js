const { readJson, writeJson } = require("./fileStore");

function sendCustomerEmail(customer, refundAmount) {
  const outbox = readJson("data/email_outbox.json");
  // BUG: no idempotency guard.
  outbox.push({
    type: "customer",
    to: customer.email,
    subject: "Your subscription downgrade is complete",
    body: `Your downgrade is complete. Refund amount: $${refundAmount}.`
  });
  writeJson("data/email_outbox.json", outbox);
}

function sendFinanceEmail(customer, creditNote) {
  const outbox = readJson("data/email_outbox.json");
  // BUG: currently missing finance email content quality and idempotency.
  outbox.push({
    type: "finance",
    to: "finance@example.com",
    subject: `Credit note created for ${customer.id}`,
    body: `Credit note ${creditNote.id} created.`
  });
  writeJson("data/email_outbox.json", outbox);
}

module.exports = { sendCustomerEmail, sendFinanceEmail };
