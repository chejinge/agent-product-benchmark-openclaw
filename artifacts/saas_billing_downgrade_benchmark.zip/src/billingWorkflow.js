const { getCustomer } = require("./customerService");
const { getSubscription, updateSubscription } = require("./subscriptionService");
const { hasUnpaidInvoice } = require("./invoiceService");
const { validateDowngrade, calculateProratedRefund } = require("./policy");
const { refund, rollbackRefund } = require("../mocks/mockBillingApi");
const subscriptionApi = require("../mocks/mockSubscriptionApi");
const { createCreditNote } = require("./creditNoteService");
const { sendCustomerEmail, sendFinanceEmail } = require("./emailService");
const { writeAudit } = require("./auditService");

async function processDowngrade(customerId, targetPlan) {
  const customer = getCustomer(customerId);
  const subscription = getSubscription(customerId);
  const unpaid = hasUnpaidInvoice(customerId);

  const check = validateDowngrade({ customer, subscription, hasUnpaid: unpaid, targetPlan });
  if (!check.allowed) {
    return { customerId, success: false, reason: check.reason };
  }

  const refundAmount = calculateProratedRefund(subscription);

  const refundResult = await refund(customerId, refundAmount);
  if (!refundResult.success) {
    writeAudit({ customerId, action: "refund_failed", status: "failed" });
    return { customerId, success: false, reason: "REFUND_FAILED" };
  }

  // BUG: no 409 retry and no rollback on downgrade failure.
  const downgradeResult = await subscriptionApi.downgrade(customerId, targetPlan);
  if (!downgradeResult.success) {
    writeAudit({ customerId, action: "downgrade_failed", status: "failed" });
    return { customerId, success: false, reason: `DOWNGRADE_${downgradeResult.code}` };
  }

  updateSubscription(customerId, {
    plan: targetPlan,
    price: 29,
    lastDowngradeAt: "2026-06-06"
  });

  const creditNote = createCreditNote(customerId, refundAmount, refundResult.refundId);
  sendCustomerEmail(customer, refundAmount);
  sendFinanceEmail(customer, creditNote);
  writeAudit({ customerId, action: "downgrade", status: "success", refundAmount, refundId: refundResult.refundId });

  return { customerId, success: true, refundAmount, refundId: refundResult.refundId };
}

async function processBatch(customerIds, targetPlan) {
  const results = [];
  for (const customerId of customerIds) {
    results.push(await processDowngrade(customerId, targetPlan));
  }
  return results;
}

module.exports = { processDowngrade, processBatch };
