const { readJson, writeJson } = require("./fileStore");

function getSubscription(customerId) {
  return readJson("data/subscriptions.json").find((x) => x.customerId === customerId) || null;
}

function updateSubscription(customerId, patch) {
  const subscriptions = readJson("data/subscriptions.json");
  const idx = subscriptions.findIndex((x) => x.customerId === customerId);
  if (idx === -1) throw new Error(`Subscription not found: ${customerId}`);

  subscriptions[idx] = { ...subscriptions[idx], ...patch };
  writeJson("data/subscriptions.json", subscriptions);
  return subscriptions[idx];
}

module.exports = { getSubscription, updateSubscription };
