const { readJson, writeJson } = require("./fileStore");

function writeAudit(entry) {
  const audit = readJson("data/audit_log.json");

  // BUG: no idempotency guard.
  audit.push({ ...entry, timestamp: new Date().toISOString() });

  writeJson("data/audit_log.json", audit);
}

module.exports = { writeAudit };
