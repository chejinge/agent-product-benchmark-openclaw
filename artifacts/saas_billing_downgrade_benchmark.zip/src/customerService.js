const { readJson } = require("./fileStore");

function getCustomer(customerId) {
  return readJson("data/customers.json").find((x) => x.id === customerId) || null;
}

module.exports = { getCustomer };
