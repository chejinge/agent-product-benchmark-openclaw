const CURRENT_DATE = new Date("2026-06-06T00:00:00Z");

function daysBetween(start, end) {
  const startMs = new Date(start + "T00:00:00Z").getTime();
  const endMs = new Date(end + "T00:00:00Z").getTime();
  return Math.round((endMs - startMs) / (24 * 60 * 60 * 1000));
}

function validateDowngrade({ customer, subscription, hasUnpaid, targetPlan }) {
  if (!customer) return { allowed: false, reason: "CUSTOMER_NOT_FOUND" };
  if (customer.status !== "active") return { allowed: false, reason: "CUSTOMER_NOT_ACTIVE" };
  if (!subscription) return { allowed: false, reason: "SUBSCRIPTION_NOT_FOUND" };
  if (subscription.plan !== "pro_annual") return { allowed: false, reason: "NOT_PRO_ANNUAL" };
  if (subscription.status !== "active") return { allowed: false, reason: "SUBSCRIPTION_NOT_ACTIVE" };
  if (targetPlan !== "basic_monthly") return { allowed: false, reason: "INVALID_TARGET_PLAN" };

  // BUG: hasUnpaid is ignored.
  if (subscription.lastDowngradeAt) return { allowed: false, reason: "ALREADY_DOWNGRADED" };

  return { allowed: true, reason: "ALLOWED" };
}

function calculateProratedRefund(subscription) {
  const totalDays = daysBetween(subscription.startDate, subscription.endDate);
  const usedDays = daysBetween(subscription.startDate, "2026-06-06");
  const unusedDays = totalDays - usedDays;

  // BUG: should use unusedDays, currently uses usedDays.
  const amount = subscription.price * usedDays / totalDays;
  return Math.round(amount * 100) / 100;
}

module.exports = { validateDowngrade, calculateProratedRefund, daysBetween };
