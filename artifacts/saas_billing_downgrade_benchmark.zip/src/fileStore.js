const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");

function resolvePath(relativePath) {
  return path.join(ROOT, relativePath);
}

function readJson(relativePath) {
  return JSON.parse(fs.readFileSync(resolvePath(relativePath), "utf8"));
}

function writeJson(relativePath, value) {
  fs.writeFileSync(resolvePath(relativePath), JSON.stringify(value, null, 2));
}

module.exports = { readJson, writeJson, resolvePath };
