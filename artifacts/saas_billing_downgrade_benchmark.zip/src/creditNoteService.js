const { readJson, writeJson } = require("./fileStore");

function createCreditNote(customerId, amount, refundId) {
  const notes = readJson("data/credit_notes.json");

  // BUG: no idempotency guard and amount should be negative.
  const note = {
    id: `CN-${customerId}`,
    customerId,
    amount,
    refundId,
    createdAt: new Date().toISOString()
  };

  notes.push(note);
  writeJson("data/credit_notes.json", notes);
  return note;
}

module.exports = { createCreditNote };
