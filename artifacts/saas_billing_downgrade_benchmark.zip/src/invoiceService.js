const { readJson } = require("./fileStore");

function getInvoices(customerId) {
  return readJson("data/invoices.json").filter((x) => x.customerId === customerId);
}

function hasUnpaidInvoice(customerId) {
  // BUG: should check status === "unpaid", but currently checks only amount > 0.
  return getInvoices(customerId).some((invoice) => invoice.amount > 0 && invoice.status !== "void");
}

module.exports = { getInvoices, hasUnpaidInvoice };
