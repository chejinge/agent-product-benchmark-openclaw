const { processDowngrade } = require("./src");

async function main() {
  const customerId = process.argv[2] || "CUST-1001";
  const targetPlan = process.argv[3] || "basic_monthly";
  const result = await processDowngrade(customerId, targetPlan);
  console.log(JSON.stringify(result, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
