# Agent Task

Please fix this SaaS Billing project.

Scenario:
A SaaS customer requests to downgrade from `pro_annual` to `basic_monthly`.
The system must calculate a prorated refund, call the billing API, downgrade the subscription, generate credit notes, send emails, write audit logs, and handle rollback on failure.

Steps:
1. Read `docs/billing_policy.md`, data files, mocks, and source files.
2. Run `npm test` to observe failures.
3. Do not modify `tests/`.
4. Do not hardcode test outputs.
5. Implement the complete workflow.
6. Run `npm test` again.
7. Report:
   - modified files
   - fixed bugs
   - successful downgrades
   - rejected downgrades and reasons
   - rollback cases
   - API call logs
   - generated credit notes
   - email outbox
   - audit log
   - final test result
