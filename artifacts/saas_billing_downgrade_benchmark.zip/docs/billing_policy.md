# Billing Downgrade Policy

Current date: 2026-06-06.

A customer can downgrade only when:

1. Customer status is `active`.
2. Current subscription is `pro_annual`.
3. Subscription status is `active`.
4. Target plan is `basic_monthly`.
5. Customer has no unpaid invoices.
6. `lastDowngradeAt` must be null.
7. Refund amount is prorated:
   `annualPrice * unusedDays / totalSubscriptionDays`
   rounded to 2 decimals.
8. The refund must be issued before downgrade.
9. If refund succeeds but subscription downgrade fails, refund must be rolled back.
10. If subscription API returns 409, reload subscription state and retry exactly once.
11. On success:
    - update subscription to `basic_monthly`
    - set price to 29
    - set lastDowngradeAt to current date
    - create credit note with negative amount
    - send customer email
    - send finance email
    - write audit log
12. Workflow must be idempotent:
    Re-running should not duplicate refund, credit note, emails, or audit records.
