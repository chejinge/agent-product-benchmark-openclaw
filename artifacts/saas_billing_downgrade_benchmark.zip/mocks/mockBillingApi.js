const { readJson, writeJson } = require("../src/fileStore");

function logCall(entry) {
  const log = readJson("data/api_call_log.json");
  log.push({ service: "billing", ...entry, timestamp: new Date().toISOString() });
  writeJson("data/api_call_log.json", log);
}

async function refund(customerId, amount) {
  logCall({ action: "refund", customerId, amount });

  if (customerId === "CUST-1001") {
    return { success: true, refundId: "REF-1001" };
  }

  if (customerId === "CUST-1004") {
    return { success: true, refundId: "REF-1004" };
  }

  if (customerId === "CUST-1005") {
    return { success: true, refundId: "REF-1005" };
  }

  return { success: false, code: 400 };
}

async function rollbackRefund(refundId) {
  logCall({ action: "rollbackRefund", refundId });
  return { success: true, rollbackId: `ROLLBACK-${refundId}` };
}

module.exports = { refund, rollbackRefund };
