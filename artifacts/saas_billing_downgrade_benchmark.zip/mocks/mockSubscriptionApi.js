const { readJson, writeJson } = require("../src/fileStore");

function logCall(entry) {
  const log = readJson("data/api_call_log.json");
  log.push({ service: "subscription", ...entry, timestamp: new Date().toISOString() });
  writeJson("data/api_call_log.json", log);
}

async function downgrade(customerId, targetPlan) {
  const log = readJson("data/api_call_log.json");
  const previous = log.filter((x) => x.service === "subscription" && x.action === "downgrade" && x.customerId === customerId).length;

  logCall({ action: "downgrade", customerId, targetPlan });

  if (customerId === "CUST-1001") {
    return { success: true };
  }

  if (customerId === "CUST-1004" && previous === 0) {
    return { success: false, code: 409, message: "subscription version conflict" };
  }

  if (customerId === "CUST-1004" && previous === 1) {
    return { success: true };
  }

  if (customerId === "CUST-1005") {
    return { success: false, code: 500, message: "downgrade failed after refund" };
  }

  return { success: false, code: 400 };
}

module.exports = { downgrade };
