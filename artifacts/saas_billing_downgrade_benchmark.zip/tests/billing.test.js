const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const root = path.join(__dirname, "..");
process.chdir(root);

function reset() {
  execFileSync(process.execPath, [path.join(root, "tests/resetState.js")], { stdio: "inherit" });
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(path.join(root, file), "utf8"));
}

function byCustomer(results, id) {
  return results.find((x) => x.customerId === id);
}

async function main() {
  reset();
  const { processBatch, processDowngrade } = require("../src");

  const results = await processBatch(
    ["CUST-1001", "CUST-1002", "CUST-1003", "CUST-1004", "CUST-1005"],
    "basic_monthly"
  );

  assert.equal(byCustomer(results, "CUST-1001").success, true, "CUST-1001 should downgrade");
  assert.equal(byCustomer(results, "CUST-1001").refundAmount, 687.12, "CUST-1001 prorated refund should use unused days");

  assert.equal(byCustomer(results, "CUST-1002").success, false, "CUST-1002 has unpaid invoice");
  assert.equal(byCustomer(results, "CUST-1002").reason, "HAS_UNPAID_INVOICE");

  assert.equal(byCustomer(results, "CUST-1003").success, false, "CUST-1003 already downgraded/not pro annual");
  assert.equal(byCustomer(results, "CUST-1003").reason, "NOT_PRO_ANNUAL");

  assert.equal(byCustomer(results, "CUST-1004").success, true, "CUST-1004 should retry after 409");
  assert.equal(byCustomer(results, "CUST-1004").refundAmount, 1081.64);

  assert.equal(byCustomer(results, "CUST-1005").success, false, "CUST-1005 downgrade fails after refund");
  assert.equal(byCustomer(results, "CUST-1005").reason, "DOWNGRADE_ROLLED_BACK");

  const calls = readJson("data/api_call_log.json");
  const compactCalls = calls.map((x) => `${x.service}:${x.action}:${x.customerId || x.refundId || ""}:${x.code || ""}`);

  assert.equal(calls.filter((x) => x.service === "billing" && x.action === "refund" && x.customerId === "CUST-1001").length, 1);
  assert.equal(calls.filter((x) => x.service === "subscription" && x.action === "downgrade" && x.customerId === "CUST-1004").length, 2, "CUST-1004 should call downgrade twice due to 409 retry");
  assert.equal(calls.filter((x) => x.service === "billing" && x.action === "rollbackRefund" && x.refundId === "REF-1005").length, 1, "CUST-1005 must rollback refund");

  assert.equal(calls.some((x) => x.customerId === "CUST-1002"), false, "CUST-1002 should not call any API");
  assert.equal(calls.some((x) => x.customerId === "CUST-1003"), false, "CUST-1003 should not call any API");

  const subs = readJson("data/subscriptions.json");
  assert.equal(subs.find((x) => x.customerId === "CUST-1001").plan, "basic_monthly");
  assert.equal(subs.find((x) => x.customerId === "CUST-1001").price, 29);
  assert.equal(subs.find((x) => x.customerId === "CUST-1004").plan, "basic_monthly");
  assert.equal(subs.find((x) => x.customerId === "CUST-1005").plan, "pro_annual", "failed downgrade must not alter subscription");

  const creditNotes = readJson("data/credit_notes.json");
  assert.equal(creditNotes.length, 2, "Only successful downgrades should create credit notes");
  assert.deepEqual(creditNotes.map((x) => x.customerId).sort(), ["CUST-1001", "CUST-1004"]);
  assert.equal(creditNotes.find((x) => x.customerId === "CUST-1001").amount, -687.12, "credit note amount must be negative");
  assert.equal(creditNotes.find((x) => x.customerId === "CUST-1004").amount, -1081.64);

  const outbox = readJson("data/email_outbox.json");
  assert.equal(outbox.length, 4, "Each successful downgrade sends customer + finance email");
  assert.equal(outbox.filter((x) => x.type === "customer").length, 2);
  assert.equal(outbox.filter((x) => x.type === "finance").length, 2);
  assert.ok(outbox.some((x) => x.to === "alice@example.com" && x.body.includes("$687.12")));
  assert.ok(outbox.some((x) => x.to === "finance@example.com" && x.body.includes("CUST-1004")));

  const audit = readJson("data/audit_log.json");
  assert.ok(audit.some((x) => x.customerId === "CUST-1001" && x.status === "success"));
  assert.ok(audit.some((x) => x.customerId === "CUST-1004" && x.status === "success" && x.retriedAfter409 === true));
  assert.ok(audit.some((x) => x.customerId === "CUST-1005" && x.action === "rollback" && x.status === "success"));

  const secondRun = await processDowngrade("CUST-1001", "basic_monthly");
  assert.equal(secondRun.success, false);
  assert.equal(secondRun.reason, "NOT_PRO_ANNUAL");

  assert.equal(readJson("data/credit_notes.json").length, 2, "Second run must not duplicate credit note");
  assert.equal(readJson("data/email_outbox.json").length, 4, "Second run must not duplicate emails");
  assert.equal(readJson("data/audit_log.json").filter((x) => x.customerId === "CUST-1001" && x.status === "success").length, 1, "Second run must not duplicate success audit");

  console.log("All SaaS Billing downgrade benchmark tests passed");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
