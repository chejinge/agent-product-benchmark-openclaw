const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");

const customers = [
  {
    "id": "CUST-1001",
    "name": "Alice Chen",
    "email": "alice@example.com",
    "status": "active"
  },
  {
    "id": "CUST-1002",
    "name": "Bob Smith",
    "email": "bob@example.com",
    "status": "active"
  },
  {
    "id": "CUST-1003",
    "name": "Carol White",
    "email": "carol@example.com",
    "status": "active"
  },
  {
    "id": "CUST-1004",
    "name": "David Brown",
    "email": "david@example.com",
    "status": "active"
  },
  {
    "id": "CUST-1005",
    "name": "Eve Black",
    "email": "eve@example.com",
    "status": "active"
  }
];
const subscriptions = [
  {
    "customerId": "CUST-1001",
    "plan": "pro_annual",
    "status": "active",
    "startDate": "2026-01-01",
    "endDate": "2027-01-01",
    "price": 1200,
    "currency": "USD",
    "lastDowngradeAt": null
  },
  {
    "customerId": "CUST-1002",
    "plan": "pro_annual",
    "status": "active",
    "startDate": "2026-01-01",
    "endDate": "2027-01-01",
    "price": 1200,
    "currency": "USD",
    "lastDowngradeAt": null
  },
  {
    "customerId": "CUST-1003",
    "plan": "basic_monthly",
    "status": "active",
    "startDate": "2026-01-10",
    "endDate": "2026-02-10",
    "price": 29,
    "currency": "USD",
    "lastDowngradeAt": "2026-02-01"
  },
  {
    "customerId": "CUST-1004",
    "plan": "pro_annual",
    "status": "active",
    "startDate": "2026-05-01",
    "endDate": "2027-05-01",
    "price": 1200,
    "currency": "USD",
    "lastDowngradeAt": null
  },
  {
    "customerId": "CUST-1005",
    "plan": "pro_annual",
    "status": "active",
    "startDate": "2026-03-01",
    "endDate": "2027-03-01",
    "price": 1200,
    "currency": "USD",
    "lastDowngradeAt": null
  }
];
const invoices = [
  {
    "id": "INV-2001",
    "customerId": "CUST-1001",
    "amount": 1200,
    "currency": "USD",
    "status": "paid",
    "dueDate": "2026-01-01",
    "paidAt": "2026-01-01"
  },
  {
    "id": "INV-2002",
    "customerId": "CUST-1002",
    "amount": 1200,
    "currency": "USD",
    "status": "unpaid",
    "dueDate": "2026-01-01",
    "paidAt": null
  },
  {
    "id": "INV-2003",
    "customerId": "CUST-1003",
    "amount": 29,
    "currency": "USD",
    "status": "paid",
    "dueDate": "2026-02-10",
    "paidAt": "2026-02-10"
  },
  {
    "id": "INV-2004",
    "customerId": "CUST-1004",
    "amount": 1200,
    "currency": "USD",
    "status": "paid",
    "dueDate": "2026-05-01",
    "paidAt": "2026-05-01"
  },
  {
    "id": "INV-2005",
    "customerId": "CUST-1005",
    "amount": 1200,
    "currency": "USD",
    "status": "paid",
    "dueDate": "2026-03-01",
    "paidAt": "2026-03-01"
  }
];

function writeJson(file, value) {
  fs.writeFileSync(path.join(root, file), JSON.stringify(value, null, 2));
}

writeJson("data/customers.json", customers);
writeJson("data/subscriptions.json", subscriptions);
writeJson("data/invoices.json", invoices);
writeJson("data/credit_notes.json", []);
writeJson("data/email_outbox.json", []);
writeJson("data/audit_log.json", []);
writeJson("data/api_call_log.json", []);
console.log("State reset complete");
