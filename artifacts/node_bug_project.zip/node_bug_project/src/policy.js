// policy.js — BUGS: 30-day window has off-by-one
const CURRENT_DATE = new Date('2026-06-06');

function daysBetween(orderDate) {
  const ms = new Date(orderDate + 'T00:00:00Z').getTime();
  return Math.floor((CURRENT_DATE.getTime() - ms) / (86400000));
}

function isWithinRefundWindow(orderDate) {
  // BUG: should be > 30, currently > 31 (off by one)
  const days = daysBetween(orderDate);
  return days <= 30; // correct interpretation but the check uses > 31 elsewhere
}

function calculateRefund(order) {
  const amount = order.quantity * order.unitPrice * (1 - order.discountRate);
  return Math.round(amount * 100) / 100;
}

module.exports = { daysBetween, isWithinRefundWindow, calculateRefund };