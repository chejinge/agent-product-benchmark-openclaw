const fs = require('fs');

function readJson(relPath) {
  return JSON.parse(fs.readFileSync(relPath, 'utf8'));
}

function writeJson(relPath, data) {
  fs.writeFileSync(relPath, JSON.stringify(data, null, 2));
}

module.exports = { readJson, writeJson };