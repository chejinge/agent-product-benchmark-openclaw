// inventory.js — BUGS: calculateLineTotal uses wrong direction
const { readJson, writeJson } = require('./fileStore');

function calculateLineTotal(quantity, unitPrice, discountRate) {
  // BUG: discount should SUBTRACT, not add
  return quantity * unitPrice * (1 + discountRate);
}

function buildOrderSummary(items) {
  const total = items.reduce((sum, item) => {
    return sum + calculateLineTotal(item.quantity, item.unitPrice, item.discountRate || 0);
  }, 0);
  return { total: Math.round(total * 100) / 100, itemCount: items.length };
}

module.exports = { calculateLineTotal, buildOrderSummary };