// orderService.js — BUG: field name typo (refund vs refunded)
const { readJson, writeJson } = require('./fileStore');

function getOrder(orderId) {
  return readJson('data/orders.json').find(o => o.orderId === orderId) || null;
}

function markRefunded(orderId) {
  const orders = readJson('data/orders.json');
  const idx = orders.findIndex(o => o.orderId === orderId);
  if (idx === -1) throw new Error('Order not found');
  // BUG: wrong field name — 'refund' instead of 'refunded'
  orders[idx].refund = true;
  writeJson('data/orders.json', orders);
}

module.exports = { getOrder, markRefunded };