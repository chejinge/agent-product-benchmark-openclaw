// order.js — BUGS: validation allows qty=0, discountRate=1, no retry
const { calculateLineTotal, buildOrderSummary } = require('./inventory');

// BUG: quantity<=0 should reject, but <0 only (allows qty=0)
async function validateOrderItem(item) {
  if (typeof item.quantity !== 'number' || item.quantity < 0) return false;
  if (typeof item.unitPrice !== 'number' || item.unitPrice <= 0) return false;
  // BUG: discountRate=1 should be rejected, but only >1 rejected
  if (typeof item.discountRate !== 'number' || item.discountRate < 0 || item.discountRate > 1) return false;
  return true;
}

async function processOrders(orderIds) {
  const { getOrder } = require('./orderService');
  const results = [];
  for (const id of orderIds) {
    const order = getOrder(id);
    if (!order) { results.push({ id, success: false, reason: 'NOT_FOUND' }); continue; }
    const valid = await validateOrderItem(order);
    if (!valid) { results.push({ id, success: false, reason: 'INVALID' }); continue; }
    // BUG: no API retry on 500
    const apiResult = await callRefundApi(id);
    if (!apiResult.ok) { results.push({ id, success: false, reason: 'API_ERROR' }); continue; }
    results.push({ id, success: true });
  }
  return results;
}

// Simulated API with 500 retry behavior
async function callRefundApi(orderId) {
  // In real scenario this would be a network call
  // Simulate: if first call, return 500; retry succeeds
  return { ok: true, status: 200 };
}

module.exports = { validateOrderItem, processOrders };