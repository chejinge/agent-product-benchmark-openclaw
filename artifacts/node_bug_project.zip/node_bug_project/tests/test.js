const assert = require('assert');
const path = require('path');
const fs = require('fs');

const root = path.join(__dirname, '..');
process.chdir(root);

// Test 1: calculateLineTotal — discount should subtract, not add
const { calculateLineTotal } = require('../src/inventory');
assert.equal(calculateLineTotal(2, 100, 0.1), 180, 'discount=0.1 should give 180, not 220');
console.log('Test 1 passed: calculateLineTotal discount direction');

// Test 2: validateOrderItem — qty=0 must be rejected
const { validateOrderItem } = require('../src/order');
(async () => {
  const r1 = await validateOrderItem({ quantity: 0, unitPrice: 10, discountRate: 0 });
  assert.equal(r1, false, 'qty=0 must be rejected');
  console.log('Test 2 passed: qty=0 rejected');

  const r2 = await validateOrderItem({ quantity: 1, unitPrice: 10, discountRate: 1 });
  assert.equal(r2, false, 'discountRate=1 must be rejected');
  console.log('Test 3 passed: discountRate=1 rejected');

  const r3 = await validateOrderItem({ quantity: 1, unitPrice: 0, discountRate: 0 });
  assert.equal(r3, false, 'unitPrice=0 must be rejected');
  console.log('Test 4 passed: unitPrice=0 rejected');
})();

// Test 5: isWithinRefundWindow — 30 days inclusive, 31 not
const { isWithinRefundWindow, daysBetween } = require('../src/policy');
assert.equal(isWithinRefundWindow('2026-05-06'), true, '6-day-old order must be inside window');
assert.equal(isWithinRefundWindow('2026-05-05'), true, '7-day-old order must be inside window');
assert.equal(isWithinRefundWindow('2026-04-06'), false, '31-day-old order must be outside window');
assert.equal(isWithinRefundWindow('2026-04-05'), true, '30-day-old order must be inside (inclusive)');
console.log('Test 5 passed: refund window boundary correct');

// Test 6: markRefunded must set 'refunded' field (not 'refund')
const { markRefunded } = require('../src/orderService');
const ordersPath = path.join(root, 'data/orders.json');
const original = JSON.parse(fs.readFileSync(ordersPath));
// Patch ORD-005
const backup = JSON.parse(JSON.stringify(original));
try {
  markRefunded('ORD-005');
  const after = JSON.parse(fs.readFileSync(ordersPath));
  const ord5 = after.find(o => o.orderId === 'ORD-005');
  assert.equal(ord5.refunded, true, "field must be 'refunded', not 'refund'");
  console.log('Test 6 passed: markRefunded sets correct field');
} finally {
  fs.writeFileSync(ordersPath, JSON.stringify(backup, null, 2));
}

console.log('\nAll Node.js Bug Fix benchmark tests passed');